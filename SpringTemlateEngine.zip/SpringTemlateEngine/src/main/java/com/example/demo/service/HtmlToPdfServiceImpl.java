
package com.example.demo.service;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring5.SpringTemplateEngine;

import com.example.demo.util.PdfGeneratorUtil;

@Service
public class HtmlToPdfServiceImpl implements HtmlToPdfService {

	@Autowired
	SpringTemplateEngine templateEngine;

	@Override
	public InputStream generateHtmlToPdfService() {
		//Set the Data here whatever you want to display into pdf file
		Context context = new Context();
		context.setVariable("name", "sudhir");
		String content = templateEngine.process("demo/a", context);
		byte[] byteArray;
		try {
			byteArray = PdfGeneratorUtil.convertToPdf(content);
			InputStream inputStream = new ByteArrayInputStream(byteArray);
			return inputStream;
		} catch (java.io.IOException e) {
			e.printStackTrace();
		}
		return null;
	}

}
