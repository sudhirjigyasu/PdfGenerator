
package com.example.demo.service;

import java.io.InputStream;

import org.springframework.stereotype.Service;

@Service
public interface HtmlToPdfService {

	InputStream generateHtmlToPdfService();

}
