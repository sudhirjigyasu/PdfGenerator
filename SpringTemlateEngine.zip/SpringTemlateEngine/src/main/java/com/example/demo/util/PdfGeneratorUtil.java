
package com.example.demo.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;

public class PdfGeneratorUtil {

	public static byte[] convertToPdf(String html) throws IOException {
		File outputFile = new File("template.pdf");
		HtmlConverter.convertToPdf(html, new FileOutputStream(outputFile), new ConverterProperties());
		byte[] content = FileUtils.readFileToByteArray(outputFile);
		return content;
	}
}
